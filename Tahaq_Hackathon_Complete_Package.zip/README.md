# تحقّق | Tahaqaq — Digital Community Shield

**Hackathon MVP / proof of concept.** Arabic RTL, browser-based, mobile-friendly. Four equal team members; no project manager. If the registration portal requires a leader, designate an administrative contact only.

## Problem and solution
Fraudulent messages and impersonation campaigns use convincing branding, urgency and offers. Tahaqaq accepts pasted text or a screenshot, extracts Arabic/English text with client-side OCR (when available), identifies **heuristic risk signals**, extracts links/phone numbers and displays an explainable warning. **Unverified identity is never shown as verified or safe.**

## Run
1. Host `index.html` on an HTTPS static host (e.g. Netlify Drop) and open on Safari/Chrome. No build step or API keys.
2. Use the three built-in example buttons for a reliable offline presentation.
3. For a real screenshot: choose an image, tap **استخراج النص من الصورة**, wait for OCR, review/correct the text, then tap **تحليل الرسالة**. OCR requires network access to download Tesseract.js and Arabic/English language models.
4. Alternatively paste message text directly and tap **تحليل الرسالة**.
5. For local inspection, serve the folder with `python3 -m http.server 8000` and visit `http://localhost:8000` (OCR still requires Internet).

## Architecture and technical choices
- Single-page static HTML/CSS/JavaScript for portability, low deployment friction, and iPhone compatibility.
- Tesseract.js 5.1.1 loaded on demand from jsDelivr for browser OCR; no screenshot is intentionally uploaded to an application backend.
- Deterministic rules with weighted risk indicators and plain-language explanations. **Not a trained AI classifier**; rule-based MVP is transparent but limited.
- No government/business registry integration, live domain reputation, phone ownership lookup, secure-contact directory or iOS Back Tap integration in this version.
- All results show identity as **unverified**; no official contact is invented.

## Privacy
Processing is local to the browser after OCR assets load; images are not sent to an app-owned server. Third-party CDN requests occur when OCR loads, so do not promise fully offline or zero network metadata. No user account, analytics, backend database or intentional persistent storage. Do not upload sensitive real-world case material to untrusted hosting.

## Limitations and trade-offs
- False positives and false negatives are possible; keywords, international dialing codes, logos and links do not prove fraud.
- OCR can fail, especially with small, compressed, or stylized Arabic text. The app does not classify an image if OCR extracts no text; manual correction is supported.
- Text-only signals cannot independently establish sender identity, business legitimacy, or URL destination safety.
- The app has not undergone a measured benchmark, security audit, iOS device acceptance test, or official integration test. No detection accuracy percentage is claimed.
- The sample WhatsApp promotion is **user-reported as fraudulent**; its status is not independently confirmed by the MVP.

## Next steps
Verified authoritative registries via authorized APIs; domain/URL reputation and redirect inspection on a controlled backend; privacy-preserving, labeled evaluation dataset; supervised multilingual model with calibrated uncertainty; safe reporting workflow; iOS Share Extension and Shortcuts API for triple Back Tap.

## Source and tests
- `index.html`: complete executable MVP source.
- `tests/test_rules.js`: executable Node.js regression tests of the embedded risk engine.
- Run: `node tests/test_rules.js`.
- `TECHNICAL_DOCUMENTATION.md`: architecture, privacy, risk model and limitations.
- `DEMO_SCRIPT_AR.md`: suggested demonstration and honest answers for judges.
- `Tahaq_Hackathon_Presentation.pptx`: presentation.

## GitHub submission
Create a repository, upload **all files to the `main` branch**, and submit the repository URL through the organizer's submission web app when supplied. If organizers explicitly require `master`, set the default branch to `master` and upload there. **This ZIP is not itself a GitHub submission.**

## Intellectual property
The team retains its original contributions. Tesseract.js and its OCR assets are third-party dependencies governed by their own licenses; review licenses before production redistribution. Avoid using third-party logos in the product without authorization.
